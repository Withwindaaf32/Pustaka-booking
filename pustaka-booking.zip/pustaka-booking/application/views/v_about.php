<section>
	<h1><?php echo $judul ?></h1>
	<h4>Nama</h4>
	<ul type="disc">
		<li>Nama Depan : Rikoairlan</li>
		<li>Nama Belakang : Ramadhan</li>
	</ul>
	<br>
	<h4>Alamat</h4>
	<ul type="none">
		<li> jl. blok duku no.21</li>
	</ul>
	
	<h4>Tempat Lahir</h4>
	<ul type="none">
		<li>Cibubur</li>
	</ul>

	<h4>Olah Raga Favorit</h4>
	<ul type="square">
		<li>Fitness</li>
	</ul>
	

</section>