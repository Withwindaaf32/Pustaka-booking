</div>
<script type="text/javascript">
	$(document).ready(function(){
		$("#datatableid").dataTable();
	});
	$('.alert-message').alert().delay(3000).slideUp('slow');
</script>

<script src="https://cdn.datatables.net/1.11.0/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.0/js/dataTables.bootstrap5.min.js"></script>
</body>
</html>